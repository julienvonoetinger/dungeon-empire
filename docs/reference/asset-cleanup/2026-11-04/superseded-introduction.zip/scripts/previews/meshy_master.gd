extends Node3D
## Real supplied meshes, driven by one baked Blender clip and an explicit clock.
const MODEL = preload("res://assets/previews/master-meshy/master-invocation.glb")
var model: Node3D
var player: AnimationPlayer
var eye_control: Node3D
var volute_control: Node3D
var clip: StringName
var clock := 0.0

func _ready() -> void:
	model = MODEL.instantiate()
	add_child(model)
	player = model.find_children("*","AnimationPlayer",true,false)[0]
	eye_control = model.find_child("Eye_Control",true,false)
	volute_control = model.find_child("Volute_Control",true,false)
	for name in player.get_animation_list():
		if name != &"RESET":
			clip = name
			break
	assert(not clip.is_empty(),"Meshy asset must contain its baked animation")
	player.get_animation(clip).loop_mode = Animation.LOOP_NONE
	player.play(clip)
	player.pause()
	present(0.0)

func present(time: float) -> void:
	if not is_instance_valid(player): return
	clock = clampf(time,0.0,18.0)
	player.seek(clock,true)
	# Near-zero scale is retained in glTF for invertible transforms; visibility
	# is explicit so even a very close camera cannot reveal an early eye.
	eye_control.visible = clock > 3.0
	volute_control.visible = clock > 0.0
