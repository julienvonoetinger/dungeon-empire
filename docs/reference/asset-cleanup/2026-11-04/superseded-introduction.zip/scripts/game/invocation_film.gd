extends Control
## Shot boundaries are on the same clock as character poses, the vortex and the map reveal.
enum Shot { WAIT, SIGN, WAKE, ELDER, MANIFEST, GAZE, PACT, CAVERN }
const CUTS := [0., 1.8, 3.6, 5.7, 8., 11., 13.6, 15.8, 18.]
const DURATION := 18.
const ALTAR := Vector2(500, 462)
const SEATS := [Vector2(-49,-41),Vector2(53,-40),Vector2(-106,-8),Vector2(110,-6),Vector2(-86,32),Vector2(81,37),Vector2(-12,55)]
const HEIGHTS := [81.,66.,70.,65.,69.,71.,64.]
const PAINT := preload("res://assets/game/introduction/ritual-painted.webp")
const ASSEMBLY := preload("res://assets/game/introduction/invocation/assembly.webp")
const OVERHEAD := preload("res://assets/game/introduction/invocation/overhead.webp")
const ELDER := preload("res://assets/game/introduction/invocation/elder-poses.webp")
const LIGHT := preload("res://assets/dungeon/mobile-kit/light-falloff.png")
const PLATES := {
	Shot.SIGN: preload("res://assets/game/introduction/invocation/sign.webp"),
	Shot.WAKE: preload("res://assets/game/introduction/invocation/wake.webp"),
	Shot.MANIFEST: preload("res://assets/game/introduction/invocation/wait.webp"),
	Shot.CAVERN: preload("res://assets/game/introduction/invocation/cavern.webp"),
}
var seconds := 0.
var shot := Shot.WAIT
var phase := 0.
var plate := TextureRect.new()
var pigment := ShaderMaterial.new()
var presence := preload("res://scripts/game/invocation_presence.gd").new()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(presence)
	plate.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	plate.show_behind_parent = true
	pigment.shader = preload("res://shaders/invocation_film.gdshader")
	plate.material = pigment
	add_child(plate)
	plate.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_update_aspect)
	_update_aspect()
	present(0.)
	set_process(get_parent() == get_tree().root)

func _update_aspect() -> void:
	pigment.set_shader_parameter("aspect",size.x/maxf(size.y,1.))

func _process(delta: float) -> void:
	present(seconds + delta)
	if seconds >= DURATION: set_process(false)

func present(time: float) -> void:
	seconds = clampf(time,0.,DURATION)
	shot = clampi(CUTS.bsearch(seconds,false)-1,Shot.WAIT,Shot.CAVERN)
	phase = inverse_lerp(CUTS[shot],CUTS[shot+1],seconds)
	plate.texture = PLATES.get(shot)
	plate.visible = plate.texture != null
	if plate.visible:
		pigment.set_shader_parameter("shot",shot)
		pigment.set_shader_parameter("phase",phase)
		pigment.set_shader_parameter("seconds",seconds)
	if shot == Shot.MANIFEST:
		presence.present(seconds-CUTS[shot],smoothstep(.60,1.,phase))
	else:
		presence.render_target_update_mode = SubViewport.UPDATE_DISABLED
	show()
	queue_redraw()

func release() -> void:
	presence.render_target_update_mode = SubViewport.UPDATE_DISABLED
	hide()

func _draw() -> void:
	if not plate.visible:
		_draw_assembly()
	if shot == Shot.MANIFEST:
		var growth := lerpf(.45,1.,smoothstep(0.,.52,phase))
		var extent := Vector2(432,512)*minf(size.x/490.,size.y/620.)*growth
		var center := size*Vector2(.5,lerpf(.48,.36,growth))
		var foot := size*Vector2(.54,.58)
		_draw_light(foot,Vector2(extent.x*.54,extent.y*.085),Color(.13,.045,.18,.66*growth))
		_draw_light(foot,Vector2(extent.x*.40,extent.y*.065),Color(.85,.31,1.,.64*growth))
		for i in 26:
			var height := fposmod(i*.618+seconds*.34,1.)
			var angle := i*2.40+seconds*1.9+height*3.
			var lift := Vector2(cos(angle)*(.16-.10*height),sin(angle)*.028-height*.41)
			draw_circle(foot+lift*extent,minf(size.x,size.y)*.0026,Color(.91,.62,1.,sin(PI*height)*growth),true,-1.,true)
		draw_texture_rect(presence.get_texture(),Rect2(center-extent*.5,extent),false,Color(1.,1.,1.,smoothstep(0.,.14,phase)))
		_mist(smoothstep(.82,1.,phase),0.)
	elif shot in [Shot.GAZE,Shot.PACT]:
		_mist(1.-smoothstep(0.,.34,phase) if shot == Shot.GAZE else 0.,.6)
	if shot == Shot.PACT or shot == Shot.CAVERN:
		var flash := smoothstep(.76,1.,phase) if shot == Shot.PACT else 1.-smoothstep(0.,.32,phase)
		draw_rect(Rect2(Vector2.ZERO,size),Color(.42,.20,.56,flash*.85))

func _mist(crossing: float, rim: float) -> void:
	draw_rect(Rect2(Vector2.ZERO,size),Color(.23,.09,.31,crossing*.93))
	for side in [-1.,1.]:
		var edge := Vector2(size.x*(.5+side*(.54-.25*crossing)),size.y*(.46+.09*sin(seconds*1.7+side)))
		_draw_light(edge, size*Vector2(.83,1.33),Color(.44,.18,.66,rim+crossing*.34))

func _draw_light(center: Vector2, extent: Vector2, tint: Color) -> void:
	draw_texture_rect(LIGHT,Rect2(center-extent*.5,extent),false,tint)

func _draw_assembly() -> void:
	var overhead := shot in [Shot.GAZE,Shot.PACT]
	var zoom := minf(size.x/354.,size.y/300.)*(1.+.07*phase)
	var focus := ALTAR + Vector2(0,-22.)
	var pitch := 1.
	if shot == Shot.ELDER:
		zoom = minf(size.x/48.,size.y/43.)*(1.+.08*phase)
		focus = ALTAR + SEATS[0] + Vector2(0,-41.-6.*phase)
	elif overhead:
		var settle := smoothstep(0.,.55,phase) if shot == Shot.GAZE else 1.
		zoom = minf(size.x/289.,size.y/252.)*lerpf(1.12,1.,settle)
		pitch = lerpf(1.35,1.62,settle)
		focus = ALTAR + Vector2(0,-12.)
	var scale_xy := Vector2(zoom,zoom*pitch)
	var origin := size*.5-focus*scale_xy
	draw_rect(Rect2(Vector2.ZERO,size),Color("#101524"))
	draw_set_transform(origin,0.,scale_xy)
	draw_texture_rect(PAINT,Rect2(0,0,1000,1000),false,Color("#bbc0d4"))
	if shot != Shot.WAIT: _draw_seal()
	for i in SEATS.size():
		var feet: Vector2 = ALTAR+SEATS[i]
		draw_set_transform(origin+feet*scale_xy,0.,Vector2.ONE*zoom)
		_draw_oculin(i,overhead)
	draw_set_transform(Vector2.ZERO,0.,Vector2.ONE)

func _draw_seal() -> void:
	var pulse := sin(PI*clampf(phase/.65,0.,1.)) if shot == Shot.PACT else 0.
	_draw_light(ALTAR,Vector2(185,82),Color(.63,.28,.99,.29+.32*pulse))
	var curve := PackedVector2Array()
	for j in 101:
		var f := j/100.
		var a := f*TAU*1.65
		curve.append(ALTAR+Vector2(cos(a),sin(a)*.46)*(3.+64.*f))
	draw_polyline(curve,Color(.69,.32,1.,.38),3.+pulse*2.,true)
	draw_polyline(curve,Color(.9,.68,1.,.88),1.1,true)
	if pulse > 0.:
		var ring := PackedVector2Array()
		for i in 65:
			var angle := TAU*i/64.
			ring.append(ALTAR+Vector2(cos(angle),sin(angle)*.46)*(20.+phase*215.))
		draw_polyline(ring,Color(.88,.55,1.,pulse*.8),2.,true)

func _draw_oculin(index: int, overhead: bool) -> void:
	var delay := 0. if index == 0 else .22+index*.075
	var lift_at: float = CUTS[Shot.ELDER]+.15 if index==0 else CUTS[Shot.GAZE]-.08+delay
	var rise := clampf((seconds-lift_at)*24.,0.,32.)
	var bow := clampf((seconds-CUTS[Shot.PACT]-.29-delay)*24.,0.,16.)
	var frame := index*49+roundi(rise+bow)
	var tex := OVERHEAD if overhead else ASSEMBLY
	var tile := 128
	var cols := 21
	if shot == Shot.ELDER and index == 0:
		tex = ELDER
		tile = 384
		cols = 7
	var h: float = HEIGHTS[index]
	var extent := Vector2(h,h*(1.+.011*sin(seconds*1.65+index*1.7)))
	_draw_light(Vector2.ZERO,Vector2(h*.78,h*.24),Color(.025,.015,.05,.76))
	var tint := Color("#ffead3") if index==0 else Color("#d5cde5")
	draw_texture_rect_region(tex,Rect2(-extent*Vector2(.5,.86),extent),Rect2((frame%cols)*tile,floori(float(frame)/cols)*tile,tile,tile),tint)
	if tex == ELDER:
		var reflection := smoothstep(28.,32.,rise)
		_draw_light(extent*Vector2(-.013,-.65),Vector2(3.,2.),Color(.91,.71,1.,reflection*.75))
