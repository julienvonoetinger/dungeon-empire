extends SubViewport
## The camera orbits the skinned Meshy surface and passes into its surrounding haze.
const MODEL = preload("res://assets/game/introduction/invocation/presence.glb")
var camera := Camera3D.new()
var smoke := ShaderMaterial.new()
var coils := ShaderMaterial.new()
var rig: Skeleton3D
var joints := PackedInt32Array()

func _ready() -> void:
	own_world_3d = true
	transparent_bg = true
	size = Vector2i(432,512)
	render_target_update_mode = SubViewport.UPDATE_DISABLED
	var model := MODEL.instantiate()
	add_child(model)
	model.scale = Vector3(1.22,1.,1.22)
	rig = model.find_children("*","Skeleton3D",true,false)[0]
	for i in 5:
		joints.append(rig.find_bone("Coil%d"%i))
	coils.shader = preload("res://shaders/invocation_coils.gdshader")
	for part in model.find_children("*","MeshInstance3D",true,false):
		part.material_override = coils
	var volume := MeshInstance3D.new()
	var bounds := BoxMesh.new()
	bounds.size = Vector3.ONE*2.
	volume.mesh = bounds
	smoke.shader = preload("res://shaders/invocation_volume.gdshader")
	volume.material_override = smoke
	add_child(volume)
	add_child(camera)
	camera.fov = 34.
	camera.near = .03
	camera.current = true

func present(time: float, approach: float) -> void:
	render_target_update_mode = SubViewport.UPDATE_ALWAYS
	smoke.set_shader_parameter("clock_time",time)
	coils.set_shader_parameter("clock_time",time)
	for i in joints.size():
		var wave := time*1.55-i*.63
		rig.set_bone_pose_rotation(joints[i],Quaternion(Vector3.UP,.15*sin(wave))*Quaternion(Vector3.RIGHT,.055*sin(wave+.8)))
	var distance_to_altar := lerpf(4.45,.55,approach)
	var orbit := -.35+.38*time
	camera.position = Vector3(sin(orbit)*distance_to_altar,lerpf(-.48,.28,approach),cos(orbit)*distance_to_altar)
	camera.look_at(Vector3(0,.04,0))
